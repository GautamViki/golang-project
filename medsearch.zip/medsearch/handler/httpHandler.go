package handler

type httpHandler struct {
}

func NewHttpHandler() *httpHandler {
	return &httpHandler{}
}
